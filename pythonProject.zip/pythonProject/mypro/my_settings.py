DATABASES = {
    'default' : {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'exhibition',
        'USER': 'redo',
        'PASSWORD': 'memento!',
        'HOST': 'covac-database.cr30zu6nndkq.ap-northeast-2.rds.amazonaws.com',
        'PORT': '3306',
    }
}


SECRET_KEY = 'django-insecure-k5vy@fglx&(1r=g7fjj5!29rl5#!tnts&)=n)!(41a_!!d&dj('